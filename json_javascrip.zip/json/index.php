<!DOCTYPE HTML>
	<html lang="en-US">

	<head>
		<meta charset="UTF-8">
		<title>GET METHOD</title>
		<?php include("header.php")?>
		<script type="text/javascript">
			function showUser(str) {
				if (str == "") {
					document.getElementById("txtHint").innerHTML = "";
					return;
				} else {
					var xmlhttp = new XMLHttpRequest();
					xmlhttp.onreadystatechange = function () {
						if (this.readyState == 4 && this.status == 200) {
							data = JSON.parse(this.responseText);
							document.getElementById("id").value = data[0].id;
							document.getElementById("lname").value = data[0].lname;
							document.getElementById("email").value = data[0].email;
							document.getElementById("job").value = data[0].job;
							console.log(data[0]['job']);
						}
					};

					xmlhttp.open("GET",	"getData.php?str=" + str, true);
					xmlhttp.send();
				}
			}
			function call() {
				console.log("HEllo....");


				var xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function () {
					if (this.readyState == 4 && this.status == 200) {
						document.getElementById("users").innerHTML = this.responseText;
					}
				};

				xmlhttp.open("GET","getPerson.php?", true);
				xmlhttp.send();
			}
		</script>
	</head>

	<body onload="call()">

		<div class="container ">
			<h2 class = "text-center">Horizontal form</h2>
			<hr>
			<form class="form-horizontal " action="/action_page.php">
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-10">
						<div class="checkbox">
							<input type="number" id="id" placeholder="ID">
						</div>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-2" for="email">Fname-Name:</label>
					<div class="col-sm-6">
						<select class="form-control" id="users" onchange="showUser(this.value);"></select>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-2" for="pwd">Last-Name:</label>
					<div class="col-sm-6">
						<input type="text" class="form-control" id="lname" placeholder="Enter last name">
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-2" for="pwd">E-mail:</label>
					<div class="col-sm-6">
						<input type="text" class="form-control" id="email" placeholder="Enter email">
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-2" for="pwd">job:</label>
					<div class="col-sm-6">
						<input type="text" class="form-control" id="job" placeholder="Enter job">
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-6 text-center">
						<button type="submit" class="btn btn-info ">Submit</button>
					</div>
				</div>
			</form>
		</div>
		<p id="txtHint"></p>
	</body>

	</html>