<?php
	
	$str = $_GET['str'];
	//echo $str;
	$con = mysqli_connect('localhost', 'Hitesh', 'online');
	if($con){
		mysqli_select_db($con, "test");
		$sql = "SELECT * FROM `user` WHERE fname = '".$str."' ";
		$result = mysqli_query($con, $sql);
		foreach($result as $val){		
			$data[] = array("id" => $val['id'],
							"fname" => $val['fname'],
							"lname" => $val['lname'],
							"email" => $val['email'],
							"job"   => $val['job']
						);		
		}
		// Encoding array in JSON format
		echo json_encode($data);
	}else
		echo"connection not establish";


?>